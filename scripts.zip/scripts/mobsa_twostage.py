# -*- coding: utf-8 -*-
"""
Created on Fri May 28 17:35:48 2021

@author: 53ym
"""
import numpy as np
import random
import  twostage_model as fnc#testfun as fnc 
import math

p_optimal=a=[128.1,123.5,120.2,119.2,111.2,110.1,107.1,102.9,102.8,102.6,100.9,100.6,100.4,99.6,94.5,91.5,91.05,88.1,87.2]

def mobsa1(popsize,data,dim,DIM_RATE,low,up,epoch):
    pop=GeneratePopulation(popsize,dim,low,up)
    fitnesspop=fnc.fitnesspopfun(pop,data)#计算种群适度值
    historical_pop=GeneratePopulation(popsize,dim,low,up) # see Eq.2 in [1]
    globalminimum=[]
    for epk in range(epoch):
        if random.random()<random.random():
            random.shuffle(historical_pop)#随机洗牌函数
        F=get_scale_factor();
        map=[[0 for i in range(dim)] for j in range(popsize)]
        if random.random()<random.random():
            for i in range(popsize):
                u=[k for k in range(dim)]
                random.shuffle(u)
                ceil1=math.ceil(DIM_RATE*random.random()*dim)
                for k in range(ceil1):
                        map[i][u[k]]=1
        else:
            for i in range(popsize):
                randi=random.randint(0, dim-1)
                map[i][randi]=1
        offsprings=[[pop[i][j]-map[i][j]*F*(historical_pop[i][j]-pop[i][j]) for j in range(len(pop[i]))]for i in range(len(pop))]
        offsprings=BoundaryControl(offsprings,dim, low, up)
        #selection-II
        fitnessoffsprings=fnc.fitnesspopfun(offsprings,data)
        ind=[True if fitnessoffsprings[i]<fitnesspop[i] else False for i in range(len(fitnessoffsprings))]
        fitnesspop=[fitnessoffsprings[i] if ind[i]==True else fitnesspop[i] for i in range(len(fitnessoffsprings))]
        pop=[offsprings[i].copy() if ind[i]==True else pop[i].copy() for i in range(len(fitnessoffsprings))]
        if epk%2==0:
            globalminimum=globalminimum+[min(fitnesspop)]
        print("epoch:-------------"+str(epk)+"---"+str(data)+"---")

        
    return globalminimum        
                    
                
    
    
def GeneratePopulation(popsize,dim,low,up):
    return[[random.randint(low[j]+1,up[j]*10000)/10000 for j in range(dim)] for i in range(popsize)]

def BoundaryControl(pop,dim,low,up):
    pop1=pop
    for i in range(len(pop1)):
        for j in range(dim):
                if (pop1[i][j]<low[j]) or (pop1[i][j]>up[j]):
                    pop1[i][j]=random.randint(low[j]+1,up[j]*10000)/10000
    return pop1

def get_scale_factor():
    return 3*np.random.randn()

def Pareto_evalu(fitnesspop1,fitnesspop2,popsize):#1就是前者完全优于后者；-1就是前者完全劣于后者；0就是前者等同于后者
    F1=[0 for i in range(popsize)]
    for i in range(popsize):
        compare1=complist(fitnesspop1[i], fitnesspop2[i])
    if sum(compare1)==popsize:
        F1[i]=1
    elif sum(compare1)==0:
        F1[i]=-1##这个地方可能有问题
    else:
        F1[i]=0
    return F1

def complist(l1,l2):
    return [-1 if l1[k]<l2[k] else 0 if l1[k]==l2[k] else 1 for k in range(len(l1))]
        
def Pareto_min(fitnesspop):
    F2=[]
    for i in range(len(fitnesspop)):
        assis=[j for j in range(len(fitnesspop)) if i!=j]
        assis2=[assis[j] for j in range(len(assis)) if (fitnesspop[i][0]>=fitnesspop[assis[j]][0])&(fitnesspop[i][1]>=fitnesspop[assis[j]][1])]#找出j比i好的个体
        print(assis)
        print(assis2)
        print('hello')
        if len(assis2)==0 or fitnesspop[list(set(assis2))[0]]==fitnesspop[i]:#个体i没有被支配    
          F2=F2+[i]
    return F2

def listmult(l1,l2):#返回l1点乘以l2。要求l1 l2均为数值list，且长度相同
    return [[l1[j][i]*l2[j][i] for i in range(len(l1[j]))] for j in range(len(l1))]

def listadd(l1,l2):
    return [l1[i]+l2[i] for i in range(len(l1))]

def listsub(l1,l2):
    return [[l1[j][i]-l2[j][i] for i in range(len(l1[j]))] for j in range(len(l1))]

def listchengshu(l1,k):
    return [[l1[j][i]*k for i in range(len(l1[j]))] for j in range(len(l1))]
       