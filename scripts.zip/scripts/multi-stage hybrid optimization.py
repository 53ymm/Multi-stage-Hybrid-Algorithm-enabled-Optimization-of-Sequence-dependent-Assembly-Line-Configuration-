# -*- coding: utf-8 -*-
"""
Created on Wed Jul 21 20:18:11 2021

@author: 53ym
"""
######参数设置
import time
import math
import mobsa_twostage
import matplotlib.pyplot as plt
import twostage_model

print(time.perf_counter())
n=49#生产线上的工位数量
wc=[51,39,72,52,48,72,65,79,57,66,48,75,78,55,45,53,40,61,65,49,56,47,38,57,52,57,50,64,59,51,65,76,81,45,48,63,58,46,52,49,43,42,62,50,53,66,51,56,61]#工位成本
BC=[[0 for i in range(6)] for j in range(6)]
for i in range(6):
    for j in range(6):
        if i==j:
            BC[i][j]=2.2*(i+1)
        else:
            BC[i][j]=1.1*(i+j+2)+4

t=[110.1,164.5,182.1,100.9,88.1,83.2,148.2,140.1,160.0,153.7,128.1,69.9,102.9,119.2,111.2,100.6,150.5,149.5,120.2,102.6,156.5,50.6,165.3,59.6,79.4,67.4,159.0,54.3,172.9,100.4,152.0,99.6,71.2,42.9,174.4,59.2,57.3,91.5,134.6,107.1,102.8,149.0,94.5,64.9,58.8,163.0,145.9,65.5,123.5]#各工位的作业时间
pmax=[2,2,4,2,6,1,3,3,3,3,4,2,2,2,5,4,2,3,3,4,5,1,4,1,3,6,3,4,2,3,3,2,2,5,3,5,1,4,5,2,5,3,3,3,2,4,3,2,2]#缓冲区成本
#各车间的最大并行度
ttmax=130
ecmax=4000
######参数设置
ifcontinue=0
tt=ttmax
p=[]
dim=49
low=[0 for i in range(dim)]
up=[1 for i in range(dim)]




pi=[math.ceil(t[i]/tt) for i in range(n)]

while (True):
    p.append(pi.copy())
    ttall=[t[i]/pi[i] for i in range(n)]
    bottlenecktt=max(ttall)
    print(bottlenecktt)
    bottleneck=ttall.index(bottlenecktt)
    if (pi[bottleneck]+1)>pmax[bottleneck]:
        break
    else:
        pi[bottleneck]+=1

solution=[0 for i in range(len(p))]
for i in range(len(p)):
    solution[i]=mobsa_twostage.mobsa1(100,i,dim,1,low,up,20)


s=[twostage_model.sequences(solution[i][0]) for i in range(len(solution))]
sq=[[s[i][j]+1 for j in range(len(s[i]))] for i in range(len(s))]

tt=[max([t[j]/p[i][j] for j in range(len(p[i]))]) for i in range(len(p))]
b=[[tt[i] for i in range (len(solution))],[solution[i][1] for i in range (len(solution))]]
plt.plot(b[0],b[1])

print(time.perf_counter())


