# -*- coding: utf-8 -*-
"""
Created on Thu Jul 29 20:57:16 2021

@author: 53ym
"""
import first_stage_optimization

solution=[[] for i in range(10)]

for j in range(1):
    singlerun0=first_stage_optimization.singlerun()
    solution[j]+=[singlerun0.run0(500)]